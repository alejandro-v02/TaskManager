import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { DashboardScreen } from '../ui/screens/DashboardScreen';

export type RootStackParamList = {
  Dashboard: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

/**
 * Root navigation container.
 * Currently a single-screen stack; add more screens here as the app grows.
 */
export function AppNavigator(): React.JSX.Element {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: '#0F0F1A' },
          headerTintColor: '#FFFFFF',
          headerTitleStyle: { fontWeight: '700' },
          cardStyle: { backgroundColor: '#0F0F1A' },
          headerShown: false,
        }}
      >
        <Stack.Screen
          name="Dashboard"
          component={DashboardScreen}
          options={{ title: 'Task Manager' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
