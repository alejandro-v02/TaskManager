import axios from 'axios';
import type { ApiTodo, ApiTodoResponse } from '../../domain/entities';

const BASE_URL = 'https://dummyjson.com';
const TODOS_LIMIT = 150;

/**
 * Fetches todos from the dummyjson REST API.
 * Returns a flat array of ApiTodo objects.
 */
export async function fetchTodos(): Promise<ApiTodo[]> {
  const response = await axios.get<ApiTodoResponse>(
    `${BASE_URL}/todos?limit=${TODOS_LIMIT}&skip=0`,
  );
  return response.data.todos;
}
