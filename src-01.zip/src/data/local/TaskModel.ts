import { Model } from '@nozbe/watermelondb';
import { field, date, readonly } from '@nozbe/watermelondb/decorators';
import type { Associations } from '@nozbe/watermelondb/Model';

export class TaskModel extends Model {
  static table = 'tasks';

  static associations: Associations = {
    task_attachments: { type: 'has_many', foreignKey: 'task_id' },
  };

  @field('remote_id') remoteId!: number;
  @field('title') title!: string;
  @field('completed') completed!: boolean;
  @field('user_id') userId!: number;
  @field('attachment_uri') attachmentUri!: string | null;
  @readonly @date('updated_at') updatedAt!: Date;
}