import { Database } from '@nozbe/watermelondb';
import SQLiteAdapter from '@nozbe/watermelondb/adapters/sqlite';
import { schema } from './schema';
import { TaskModel } from './TaskModel';
import { TaskAttachmentModel } from './TaskAttachmentModel';

/**
 * Initialise and export the singleton WatermelonDB Database instance.
 *
 * The SQLite adapter is used for both Android and iOS.
 * In a Jest environment the adapter falls back to an in-memory store via
 * the LokiJS adapter (configured in Jest setup or with jest preset).
 */
const adapter = new SQLiteAdapter({
  schema,
  migrations: undefined,
  jsi: false,
  onSetUpError: (error: Error) => {
    console.error('[WatermelonDB] Setup error:', error);
  },
});

export const database = new Database({
  adapter,
  modelClasses: [TaskModel, TaskAttachmentModel],
});
