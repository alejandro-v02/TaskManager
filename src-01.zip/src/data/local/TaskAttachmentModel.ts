import { Model } from '@nozbe/watermelondb';
import { field, relation } from '@nozbe/watermelondb/decorators';
import type { Associations } from '@nozbe/watermelondb/Model';
import { TaskModel } from './TaskModel';

export class TaskAttachmentModel extends Model {
  static table = 'task_attachments';

  static associations: Associations = {
    tasks: { type: 'belongs_to', key: 'task_id' },
  };

  @field('task_id') taskId!: string;
  @field('uri') uri!: string;
  @field('file_name') fileName!: string | null;
  @field('width') width!: number | null;
  @field('height') height!: number | null;
  @field('size') size!: number | null;

  @relation('tasks', 'task_id') task!: TaskModel;
}