import { Database, Q } from '@nozbe/watermelondb';
import type { ApiTodo, SyncResult } from '../../domain/entities';
import { fetchTodos } from '../remote/fetchTodos';
import { TaskModel } from '../local/TaskModel';

// ─── Pure utilities ──────────────────────────────────────────────────────────

export function extractInitials(name: string): string {
  if (!name || typeof name !== 'string') return '?';
  const trimmed = name.trim();
  if (!trimmed) return '?';
  const words = trimmed.split(/\s+/);
  if (words.length === 1) return words[0][0].toUpperCase();
  return (words[0][0] + words[words.length - 1][0]).toUpperCase();
}

export function nameToColor(name: string): string {
  if (!name || typeof name !== 'string') return 'hsl(200, 60%, 45%)';
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
    hash = hash & hash;
  }
  const hue = Math.abs(hash) % 360;
  return `hsl(${hue}, 60%, 45%)`;
}

export function userIdToName(userId: number): string {
  const names = [
    'Alice Martin', 'Bob Chen', 'Carlos Rivera', 'Diana Prince',
    'Erik Svensson', 'Fatima Al-Hassan', 'George Kim',
    'Helena Santos', 'Ivan Petrov', 'Julia Weber',
  ];
  const index = (userId > 0) ? (userId - 1) % names.length : 0;
  return names[index];
}

// ─── Sync ────────────────────────────────────────────────────────────────────

export async function syncTodos(database: Database): Promise<SyncResult> {
  const result: SyncResult = { created: 0, updated: 0, failed: 0 };

  let apiTodos: ApiTodo[];
  try {
    apiTodos = await fetchTodos();
  } catch (error) {
    console.warn('[syncService] API fetch failed, continuing offline:', error);
    return result;
  }

  const tasksCollection = database.get<TaskModel>('tasks');

  await database.write(async () => {
    for (const apiTodo of apiTodos) {
      try {
        const existing = await tasksCollection
          .query(Q.where('remote_id', apiTodo.id))
          .fetch();

        if (existing.length > 0) {
          await existing[0].update((record) => {
            // Solo actualizamos el título desde la API
            // El estado completed y attachmentUri se preservan localmente
            record.title = apiTodo.todo;
            record.userId = apiTodo.userId;
            // NO tocamos record.completed ni record.attachmentUri
          });
          result.updated += 1;
        } else {
          // Tarea nueva — usamos el estado de la API como inicial
          await tasksCollection.create((record) => {
            record.remoteId = apiTodo.id;
            record.title = apiTodo.todo;
            record.completed = apiTodo.completed;
            record.userId = apiTodo.userId;
          });
          result.created += 1;
        }
      } catch (itemError) {
        console.error('[syncService] Failed to upsert todo', apiTodo.id, itemError);
        result.failed += 1;
      }
    }
  });

  console.log(
    `[syncService] Sync complete — created: ${result.created}, updated: ${result.updated}, failed: ${result.failed}`,
  );
  return result;
}

export async function toggleTaskCompletion(
  task: TaskModel,
  completed: boolean,
): Promise<void> {
  await task.db.write(async () => {
    await task.update((record) => {
      record.completed = completed;
    });
  });
}

export async function saveAttachmentUri(
  task: TaskModel,
  uri: string,
): Promise<void> {
  await task.db.write(async () => {
    await task.update((record) => {
      record.attachmentUri = uri;
    });
  });
}