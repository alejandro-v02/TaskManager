package com.taskdashboard

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView
import com.facebook.react.uimanager.SimpleViewManager
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.annotations.ReactProp

class AvatarViewManager : SimpleViewManager<TextView>() {

    override fun getName() = "AvatarView"

    override fun createViewInstance(context: ThemedReactContext): TextView {
        val tv = TextView(context)
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        tv.textSize = 16f
        tv.setTypeface(null, Typeface.BOLD)
        return tv
    }

    @ReactProp(name = "name")
    fun setName(view: TextView, name: String) {
        // Extraer iniciales
        val parts = name.trim().split(" ")
        val initials = if (parts.size >= 2) {
            "${parts[0][0]}${parts[parts.size - 1][0]}".uppercase()
        } else {
            parts[0][0].uppercase()
        }
        view.text = initials

        // Generar color a partir del hash del nombre
        val colors = listOf(
            "#E57373", "#F06292", "#BA68C8", "#7986CB",
            "#4FC3F7", "#4DB6AC", "#81C784", "#FFD54F",
            "#FF8A65", "#A1887F"
        )
        val index = Math.abs(name.hashCode()) % colors.size
        val bgColor = Color.parseColor(colors[index])

        // Fondo circular
        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.OVAL
        drawable.setColor(bgColor)
        view.background = drawable
    }
}